from django.apps import AppConfig


class DatainformationConfig(AppConfig):
    name = 'datainformation'
